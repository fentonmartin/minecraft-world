#In order to ensure the integrity of the pack, I need all downloads to come from a single source, Minecarftforum.net via curse (atm it is also hosted on planetminecraft, the download will be redirected in the future, so do not fret ;) )
#If you find this pack HOSTED on another site, please notify me either via private message on minecraft forum or post directly in http://www.minecraftforum.net/topic/2111523-rush-hour-pack/


This is my version of a default pack. All textures are made 12+ per hour per day. That means the textures took on average less than 5 minutes each to create. This is so I can be sure that the pack will get updated seeing how it doesn't take me much time to actually create the textures. I hope it can serve as a catalyst for people who want to make texturepacks but are put off by the amount of time that is required to make a pack. It is my firm belief that anyone can make a better than average pack in under a month by only spending an hour per day making textures.

------------------------------

Legal stuff:


- Do not distribute my pack or textures and/or claim them as your own.

- Feel free to use in-game (loading the pack through the minecraft client), remix and/or edit my textures for your own personal use. However, you may not distribute the modified/remixed textures without my consent.

- Do not re-upload the pack elsewhere. I encourage people to link either this curse download "http://www.curse.com/texture-packs/minecraft/equanimity-32x-1-7-x-1-6-x/download" or the pack thread on minecraftforum "http://www.minecraftforum.net/topic/2111523-rush-hour-pack/". DO NOT link directly to cursecdn, this is to protect the packs integrity and to centralize comments/critique that may help me improve the pack. I do not see the reason as to why anyone would not link a self-updating link. I do not want people commenting on a week old or more upload, complaining or giving critique on things which might have already been fixed. If you really don't want to link the curse download provided above, please contact me either on minecraftforum.net via pm or by email to filmjolk_2@hotmail.com, specify as to why you can't/wont use the provided link and maybe I can set up another download link that better fits your needs.

- Feel free to take screenshots/video recordings in/from minecraft while using this pack (loading the pack through the minecraft client) and to distribute such content with or without commercial purposes.